<?php

// No direct access
defined( '_JEXEC' ) or die;
jimport( 'joomla.application.component.controller' );

/**
 * Controller for edit current element
 * @author Aleks.Denezh
 */
class testControllertest extends JController {

   function __construct( $config=array( ) ) {
      parent::__construct( $config );
   }

}