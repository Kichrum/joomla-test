<?php
// No direct access
defined( '_JEXEC' ) or die;
?>
<div class="item-page">
   <h1><?php echo $this->item->title; ?></h1>
   <?php echo $this->item->introtext; ?>
</div>