<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

defined('_JEXEC') or die('Restricted access');
jimport('joomla.applocation.component.controller');

/**
 * Description of HelloController
 *
 * @author kichrum
 */
class HelloController extends JController {
    //put your code here
}
?>
