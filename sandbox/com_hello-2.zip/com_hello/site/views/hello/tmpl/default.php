<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

defined('_JEXEC') or die('Restricted access');
?>
<h1><?php echo $this->msg; ?></h1>